//rfce and enter to get below function for the function based component, then go to the app.js and import Footer and specify inside div
//state-less component
//no constructor
import React from 'react'

function FunctionComponent() {

  return (
    <div>
      
    </div>
  )
}

export default FunctionComponent
