import React from 'react'

//create a function based component passing an argument props and calling it from main method i.e from app.js

function GreetingComponent(props) {
  return (
    <div>
      <h1>Good Morning {props.name} {props.age}</h1>
    </div>
  )
}

export default GreetingComponent
