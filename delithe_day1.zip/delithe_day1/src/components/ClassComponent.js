//type rcc(react class component) and enter for class-based component templates, i.e to get below statements, here render is it restart the class,
//then go to the app.js and import ClassComponent and specify inside div
//1.to create object using constructor inside the class.2.to render,3. to remove unwanted
//state full component
//extends component a super class and use constructor
import React, { Component } from 'react'

export default class ClassComponent extends Component {
    constructor()
    {
        super();
        this.msg='hello!!hi'
        //this.state={count:0}
    }
    //to return jsx format
  render() {  
    return (
      <div>
        <h1>{this.msg}</h1>
      </div>
    )
  }
}
