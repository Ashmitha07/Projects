//this is a class component for counting
import React, { Component } from 'react'
//dealing with states, class is a state full component
export default class Count extends Component {
    constructor(){
        super()
        this.state={
            count:0,
            count2:0,
            count3:1,
            count4:1000

        }
       
    }
    incrementCount =()=>{
        this.setState({count:this.state.count+1})
    }
    decrementCount =()=>{
        this.setState({count2:this.state.count2-1})
    }
    multiCount =()=>{
        this.setState({count3:this.state.count3*2})
    }
    divCount =()=>{
        this.setState({count4:this.state.count4/2})
    }
    resetCount=()=>{
        this.setState({
            count:0,
            count2:0,
            count3:1,
            count4:1000

        })
    }
  render() {
    return (
      <div>
        <h1>{this.state.count}</h1>
        <button onClick={this.incrementCount} class="btn btn-success">Increment</button><br></br>
        <h1>{this.state.count2}</h1>
        <button onClick={this.decrementCount}class="btn btn-warning">Decrement</button><br></br>
        <h1>{this.state.count3}</h1>
        <button onClick={this.multiCount}class="btn btn-primary">Multiple</button><br></br><br></br>
        <h1>{this.state.count4}</h1>
        <button onClick={this.divCount}class="btn btn-danger">Division</button><br></br><br></br>
        
        <button onClick={this.resetCount}class="btn btn-info">Reset</button>
      </div>
    )
  }
}
