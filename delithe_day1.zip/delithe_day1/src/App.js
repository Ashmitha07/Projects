//rfc and enter and run npm install react-router-dom in terminal to install library
import React from 'react'
import './App.css'
import {BrowserRouter,Routes,Route} from 'react-router-dom';
import Count from './components/Count';
import ClassComponent from './components/ClassComponent';
import GreetingComponent from './components/GreetingComponent';
import CountFunctionComponent from './components/CountFunctionComponent';
import Timer from './components/Timer';
export default function App() {
  return (
    <div className='App'>
      <BrowserRouter>
        <Routes>
            <Route path='/count' element={<Count/>}/>
            <Route path='/about' element={<ClassComponent/>}/>
            <Route path='/greet' element={<GreetingComponent/>}/>
            <Route path='/increment' element={<CountFunctionComponent/>}/>
            <Route path='/timer' element={<Timer/>}/>

        </Routes>
      </BrowserRouter>
    </div>
  )
}
